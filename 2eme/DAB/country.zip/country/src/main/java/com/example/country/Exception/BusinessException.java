package com.example.country.Exception;

public class BusinessException extends Exception {
    public BusinessException(String message) {
        super(message);
    }
}
