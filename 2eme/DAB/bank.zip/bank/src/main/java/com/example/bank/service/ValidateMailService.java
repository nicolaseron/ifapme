package com.example.bank.service;

public interface ValidateMailService {
    Boolean validate(String email);
}
