package com.example.bank.model;

public enum TransactionType {
    DEPOT,
    RETRAIT,
    TRANSFERT
}
