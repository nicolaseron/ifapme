package org.example.calculatrice;

import org.example.calculatrice.Entity.History;
import org.example.calculatrice.service.impl.CalculatorServiceImpl;
import org.example.calculatrice.service.impl.HistoryServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;


class CalculatriceApplicationTests {




}
