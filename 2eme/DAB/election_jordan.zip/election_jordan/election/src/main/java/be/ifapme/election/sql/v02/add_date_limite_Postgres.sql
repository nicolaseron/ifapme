alter table public.election
    add date_limite TIMESTAMP default current_timestamp;
