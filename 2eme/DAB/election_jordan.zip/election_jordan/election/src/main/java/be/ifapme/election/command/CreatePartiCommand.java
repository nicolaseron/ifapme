package be.ifapme.election.command;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CreatePartiCommand {
    private String nom;
    private String couleur;
}
