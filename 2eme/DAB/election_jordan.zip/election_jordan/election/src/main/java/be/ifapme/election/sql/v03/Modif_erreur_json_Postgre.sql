
ALTER TABLE public.erreur_json ADD COLUMN json TEXT NOT NULL;
