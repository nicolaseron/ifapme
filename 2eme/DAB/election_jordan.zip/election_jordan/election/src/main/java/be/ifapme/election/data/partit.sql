INSERT INTO public.partit (id, nom, couleur) VALUES (1, 'PS', 'rouge');
INSERT INTO public.partit (id, nom, couleur) VALUES (2, 'MR', 'bleu');
