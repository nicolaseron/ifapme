INSERT INTO public.adresse (id, localite, code_postal, rue, boite) VALUES (1, 'Namur', '5000', 'Rue des ... ', '5');
