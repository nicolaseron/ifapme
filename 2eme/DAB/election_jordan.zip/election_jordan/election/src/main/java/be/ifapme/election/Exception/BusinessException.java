package be.ifapme.election.Exception;

public class BusinessException extends Exception {
    public BusinessException(String message) {
        super(message);
    }
}
