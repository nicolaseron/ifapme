
ALTER TABLE `erreur_json` ADD `json` TEXT NOT NULL AFTER `nom_fichier`;
COMMIT;