INSERT INTO public.candidat (personne_id, election_id, partit_id, vote) VALUES (8, 1, 1, 0);
