INSERT INTO public.personne (id, nom, prenom, registre_national, adresse_id) VALUES (8, 'seron', 'nico', 'gosgjos', 1);
INSERT INTO public.personne (id, nom, prenom, registre_national, adresse_id) VALUES (10, 'seron', 'nico', 'fsfjlg', 1);
INSERT INTO public.personne (id, nom, prenom, registre_national, adresse_id) VALUES (11, 'seron', 'nico', 'peronsf', 1);
