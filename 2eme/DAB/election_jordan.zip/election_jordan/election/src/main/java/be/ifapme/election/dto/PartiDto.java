package be.ifapme.election.dto;

import lombok.Data;

@Data
public class PartiDto {
    private Integer id;
    private String nom;
    private String couleur;
}
