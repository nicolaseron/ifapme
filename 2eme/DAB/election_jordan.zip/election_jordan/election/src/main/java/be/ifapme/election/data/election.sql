INSERT INTO public.election (id, nom) VALUES (1, '2024');
INSERT INTO public.election (id, nom) VALUES (2, '2023');
