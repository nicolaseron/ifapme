package be.ifapme.election.dto;

import lombok.Data;

@Data
public class CandidatIdDto {
    private Integer personneId;
    private Integer electionId;
}
