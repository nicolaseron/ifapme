alter table public.pays
    add column url_image VARCHAR(255);
