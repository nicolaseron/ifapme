package org.example.service;

public interface CarService {
}
