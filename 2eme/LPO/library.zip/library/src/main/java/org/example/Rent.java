package org.example;

public interface Rent {
    public void rent();
    public void returning();
}